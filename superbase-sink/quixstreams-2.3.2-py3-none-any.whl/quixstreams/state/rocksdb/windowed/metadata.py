LATEST_EXPIRED_WINDOW_TIMESTAMP_KEY = b"__expired_start_gt__"

LATEST_EXPIRED_WINDOW_CF_NAME = "__expiration-index__"
