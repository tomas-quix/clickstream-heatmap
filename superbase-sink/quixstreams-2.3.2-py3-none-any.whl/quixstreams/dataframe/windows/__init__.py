from .definitions import HoppingWindowDefinition, TumblingWindowDefinition
from .base import WindowResult
